# How to Push These to Your GitHub

## 1. Set up your Profile README (shows on your GitHub homepage)
This is a special repo — must be named exactly like your username.

```bash
git clone https://github.com/atul004421/atul004421.git
cd atul004421
# copy README.md (the profile one) into this folder, replacing the existing one
git add README.md
git commit -m "Update profile README"
git push origin main
```
*(If this repo doesn't exist yet, create it on GitHub first: New Repo → name it exactly `atul004421` → check "Add a README" → create.)*

## 2. Push each project with its own README

For each project folder on your computer (e.g. `ai-ecommerce-platform`):

```bash
cd path/to/your/project-folder

# If it's not a git repo yet
git init
git add .
git commit -m "Initial commit"

# Copy the matching README.md file (e.g. ai-ecommerce-platform-README.md) 
# into the project folder and RENAME it to just README.md

git add README.md
git commit -m "Add README"

# Create the repo on GitHub first (New Repo → don't initialize with README)
# Then link and push:
git remote add origin https://github.com/atul004421/REPO-NAME.git
git branch -M main
git push -u origin main
```

Repeat for:
- `ai-ecommerce-platform`
- `student-management-system`
- `fake-news-detection`
- `healthwise`

## 3. Pin your best projects
On your GitHub profile page → click "Customize your pins" → select these 4 projects so they're the first thing recruiters see.

## 4. Quick checklist
- [ ] Profile README pushed
- [ ] All 4 project repos created on GitHub
- [ ] Each repo has its README
- [ ] Repos pinned on profile
- [ ] Add live demo links if hosted (Vercel/Render/etc.)
